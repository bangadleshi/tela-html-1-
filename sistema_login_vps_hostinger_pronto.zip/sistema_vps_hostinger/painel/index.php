
<?php
include('../includes/db.php');
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: ../index.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel Operador</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="login-container">
        <h2>Bem-vindo ao Painel</h2>
        <form action="enviar_comando.php" method="POST">
            <input type="text" name="comando" placeholder="Digite o comando"><br>
            <button type="submit">Enviar Comando</button>
        </form>
    </div>
</body>
</html>
