
<?php
include('../includes/db.php');
session_start();

$comando = $_POST['comando'];
$usuario = $_SESSION['usuario'];

$sql = "INSERT INTO comandos (usuario, conteudo) VALUES ('$usuario', '$comando')";
$conn->query($sql);

echo "Comando enviado com sucesso! <a href='index.php'>Voltar</a>";
?>
