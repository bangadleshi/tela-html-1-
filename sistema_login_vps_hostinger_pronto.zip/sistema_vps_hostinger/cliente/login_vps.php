<?php
session_start();
require_once '../includes/db_vps.php';

// Função para registrar logs
function registrarLog($usuario_id, $acao, $detalhes = '') {
    $db = getDB();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    $stmt = $db->prepare("INSERT INTO logs (usuario_id, acao, detalhes, ip_address) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isss", $usuario_id, $acao, $detalhes, $ip);
        $stmt->execute();
        $stmt->close();
    }
}

// Função para validar entrada
function validarEntrada($dados) {
    return htmlspecialchars(strip_tags(trim($dados)));
}

// Verificar se já está logado
if (isset($_SESSION['usuario_id'])) {
    header("Location: ../painel/index.php");
    exit();
}

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = validarEntrada($_POST['usuario'] ?? '');
    $senha = $_POST['senha'] ?? '';
    
    if (empty($usuario) || empty($senha)) {
        $erro = 'Usuário e senha são obrigatórios.';
    } else {
        try {
            $db = getDB();
            
            // Buscar usuário
            $stmt = $db->prepare("SELECT id, usuario, senha, ativo FROM usuarios WHERE usuario = ? AND ativo = 1");
            $stmt->bind_param("s", $usuario);
            $stmt->execute();
            $resultado = $stmt->get_result();
            
            if ($resultado->num_rows === 1) {
                $user = $resultado->fetch_assoc();
                
                // Verificar senha
                if (password_verify($senha, $user['senha'])) {
                    // Login bem-sucedido
                    $_SESSION['usuario_id'] = $user['id'];
                    $_SESSION['usuario'] = $user['usuario'];
                    $_SESSION['login_time'] = time();
                    
                    // Atualizar último login
                    $stmt_update = $db->prepare("UPDATE usuarios SET ultimo_login = NOW() WHERE id = ?");
                    $stmt_update->bind_param("i", $user['id']);
                    $stmt_update->execute();
                    $stmt_update->close();
                    
                    // Registrar log
                    registrarLog($user['id'], 'login_sucesso');
                    
                    header("Location: ../painel/index.php");
                    exit();
                } else {
                    $erro = 'Usuário ou senha incorretos.';
                    registrarLog(null, 'login_falha', "Tentativa de login com usuário: $usuario");
                }
            } else {
                $erro = 'Usuário ou senha incorretos.';
                registrarLog(null, 'login_falha', "Usuário não encontrado: $usuario");
            }
            
            $stmt->close();
            
        } catch (Exception $e) {
            error_log("Erro no login: " . $e->getMessage());
            $erro = 'Erro interno. Tente novamente mais tarde.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .erro {
            color: #d32f2f;
            background-color: #ffebee;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            border: 1px solid #ffcdd2;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login do Sistema</h2>
        
        <?php if (!empty($erro)): ?>
            <div class="erro"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <input type="text" name="usuario" placeholder="Usuário" required maxlength="50" 
                   value="<?php echo isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : ''; ?>">
            <input type="password" name="senha" placeholder="Senha" required maxlength="255">
            <button type="submit">Entrar</button>
        </form>
        
        <p><a href="cadastro_vps.php">Não tem conta? Cadastre-se</a></p>
    </div>
</body>
</html>

