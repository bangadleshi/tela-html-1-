
<?php
include('../includes/db.php');
session_start();

$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND senha = '$senha'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $_SESSION['usuario'] = $usuario;
    header('Location: ../painel/index.php');
} else {
    echo "Usuário ou senha incorretos!";
}
?>
