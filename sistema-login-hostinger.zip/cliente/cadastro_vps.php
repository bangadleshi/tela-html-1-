<?php
session_start();
require_once '../includes/db_vps.php';

// Função para validar entrada
function validarEntrada($dados) {
    return htmlspecialchars(strip_tags(trim($dados)));
}

// Função para validar email
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Função para registrar logs
function registrarLog($usuario_id, $acao, $detalhes = '') {
    $db = getDB();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    $stmt = $db->prepare("INSERT INTO logs (usuario_id, acao, detalhes, ip_address) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isss", $usuario_id, $acao, $detalhes, $ip);
        $stmt->execute();
        $stmt->close();
    }
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = validarEntrada($_POST['usuario'] ?? '');
    $email = validarEntrada($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    
    // Validações
    if (empty($usuario) || empty($email) || empty($senha) || empty($confirmar_senha)) {
        $erro = 'Todos os campos são obrigatórios.';
    } elseif (strlen($usuario) < 3 || strlen($usuario) > 50) {
        $erro = 'O usuário deve ter entre 3 e 50 caracteres.';
    } elseif (!validarEmail($email)) {
        $erro = 'Email inválido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($senha !== $confirmar_senha) {
        $erro = 'As senhas não coincidem.';
    } else {
        try {
            $db = getDB();
            
            // Verificar se usuário já existe
            $stmt = $db->prepare("SELECT id FROM usuarios WHERE usuario = ? OR email = ?");
            $stmt->bind_param("ss", $usuario, $email);
            $stmt->execute();
            $resultado = $stmt->get_result();
            
            if ($resultado->num_rows > 0) {
                $erro = 'Usuário ou email já cadastrado.';
            } else {
                // Criar hash da senha
                $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
                
                // Inserir novo usuário
                $stmt_insert = $db->prepare("INSERT INTO usuarios (usuario, email, senha) VALUES (?, ?, ?)");
                $stmt_insert->bind_param("sss", $usuario, $email, $senha_hash);
                
                if ($stmt_insert->execute()) {
                    $usuario_id = $db->getConnection()->insert_id;
                    registrarLog($usuario_id, 'cadastro_realizado');
                    
                    $sucesso = 'Cadastro realizado com sucesso! Você pode fazer login agora.';
                } else {
                    $erro = 'Erro ao realizar cadastro. Tente novamente.';
                }
                
                $stmt_insert->close();
            }
            
            $stmt->close();
            
        } catch (Exception $e) {
            error_log("Erro no cadastro: " . $e->getMessage());
            $erro = 'Erro interno. Tente novamente mais tarde.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - Sistema</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .erro {
            color: #d32f2f;
            background-color: #ffebee;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            border: 1px solid #ffcdd2;
        }
        .sucesso {
            color: #2e7d32;
            background-color: #e8f5e8;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            border: 1px solid #c8e6c9;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Cadastro no Sistema</h2>
        
        <?php if (!empty($erro)): ?>
            <div class="erro"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($sucesso)): ?>
            <div class="sucesso"><?php echo htmlspecialchars($sucesso); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <input type="text" name="usuario" placeholder="Usuário (3-50 caracteres)" required 
                   maxlength="50" minlength="3"
                   value="<?php echo isset($_POST['usuario']) ? htmlspecialchars($_POST['usuario']) : ''; ?>">
            
            <input type="email" name="email" placeholder="Email" required maxlength="100"
                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            
            <input type="password" name="senha" placeholder="Senha (mínimo 6 caracteres)" 
                   required minlength="6" maxlength="255">
            
            <input type="password" name="confirmar_senha" placeholder="Confirmar Senha" 
                   required minlength="6" maxlength="255">
            
            <button type="submit">Cadastrar</button>
        </form>
        
        <p><a href="login_vps.php">Já tem conta? Faça login</a></p>
    </div>
</body>
</html>

