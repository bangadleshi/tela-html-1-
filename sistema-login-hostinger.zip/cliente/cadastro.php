
<?php
include('../includes/db.php');

$nome = $_POST['nome'];
$sobrenome = $_POST['sobrenome'];
$email = $_POST['email'];
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

$sql = "INSERT INTO usuarios (nome, sobrenome, email, usuario, senha)
        VALUES ('$nome', '$sobrenome', '$email', '$usuario', '$senha')";

if ($conn->query($sql) === TRUE) {
    echo "Cadastro realizado com sucesso! <a href='../index.html'>Login</a>";
} else {
    echo "Erro: " . $sql . "<br>" . $conn->error;
}
?>
