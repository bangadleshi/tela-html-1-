<?php
session_start();
require_once '../includes/db_vps.php';

// Verificar se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../cliente/login_vps.php");
    exit();
}

// Função para registrar logs
function registrarLog($usuario_id, $acao, $detalhes = '') {
    $db = getDB();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    
    $stmt = $db->prepare("INSERT INTO logs (usuario_id, acao, detalhes, ip_address) VALUES (?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("isss", $usuario_id, $acao, $detalhes, $ip);
        $stmt->execute();
        $stmt->close();
    }
}

// Logout
if (isset($_GET['logout'])) {
    registrarLog($_SESSION['usuario_id'], 'logout');
    session_destroy();
    header("Location: ../cliente/login_vps.php");
    exit();
}

$usuario = $_SESSION['usuario'];
$usuario_id = $_SESSION['usuario_id'];

// Buscar informações do usuário
try {
    $db = getDB();
    $stmt = $db->prepare("SELECT usuario, email, data_criacao, ultimo_login FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $user_info = $resultado->fetch_assoc();
    $stmt->close();
} catch (Exception $e) {
    error_log("Erro ao buscar informações do usuário: " . $e->getMessage());
    $user_info = ['usuario' => $usuario, 'email' => '', 'data_criacao' => '', 'ultimo_login' => ''];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Operador</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .painel-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .user-info {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .action-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            text-align: center;
            transition: box-shadow 0.3s;
        }
        .action-card:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .btn {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-danger {
            background: #dc3545;
        }
        .btn-danger:hover {
            background: #c82333;
        }
        .status {
            color: #28a745;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="painel-container">
        <div class="header">
            <h1>Painel do Operador</h1>
            <div>
                <span class="status">● Online</span>
                <a href="?logout=1" class="btn btn-danger">Sair</a>
            </div>
        </div>
        
        <div class="user-info">
            <h3>Informações do Usuário</h3>
            <p><strong>Usuário:</strong> <?php echo htmlspecialchars($user_info['usuario']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user_info['email']); ?></p>
            <p><strong>Membro desde:</strong> <?php echo date('d/m/Y H:i', strtotime($user_info['data_criacao'])); ?></p>
            <p><strong>Último login:</strong> <?php echo $user_info['ultimo_login'] ? date('d/m/Y H:i', strtotime($user_info['ultimo_login'])) : 'Primeiro acesso'; ?></p>
        </div>
        
        <div class="actions">
            <div class="action-card">
                <h4>Enviar Comando</h4>
                <p>Execute comandos no sistema</p>
                <a href="enviar_comando_vps.php" class="btn">Acessar</a>
            </div>
            
            <div class="action-card">
                <h4>Logs do Sistema</h4>
                <p>Visualizar logs de atividades</p>
                <a href="logs_vps.php" class="btn">Visualizar</a>
            </div>
            
            <div class="action-card">
                <h4>Configurações</h4>
                <p>Alterar configurações da conta</p>
                <a href="configuracoes_vps.php" class="btn">Configurar</a>
            </div>
            
            <div class="action-card">
                <h4>Relatórios</h4>
                <p>Gerar relatórios do sistema</p>
                <a href="relatorios_vps.php" class="btn">Gerar</a>
            </div>
        </div>
        
        <div style="text-align: center; color: #666; font-size: 12px;">
            <p>Sistema de Login e Painel - Versão VPS Hostinger</p>
            <p>Sessão iniciada em: <?php echo date('d/m/Y H:i:s', $_SESSION['login_time']); ?></p>
        </div>
    </div>
</body>
</html>

